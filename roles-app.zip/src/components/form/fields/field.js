import React from 'react';
import classNames from 'classnames';
import PropTypes from 'react-proptypes';

const Field = ChildField => props => {
  const { className, label } = props;

  return (
    <div className={classNames('form-group', className)}>
      {!!label && (
        <label className="col-form-label col-form-label-sm col-md-12 col-lg-12 col-xl-4 text-lg-left text-xl-right">
          {label}
        </label>
      )}
      <div className="col-md-12 col-lg-12 col-xl-6">
        <div className="input-group input-group-sm">
          <ChildField {...props} />
        </div>
      </div>
    </div>
  );
};

Field.propTypes = {
  className: PropTypes.string,
  id: PropTypes.string,
  label: PropTypes.string,
  required: PropTypes.bool,
  type: PropTypes.string.isRequired,
  value: PropTypes.string,
};

Field.defaultProps = { required: false, type: 'text' };

export default Field;
