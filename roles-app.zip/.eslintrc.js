module.exports = {
  extends: ['react-app', 'eslint:recommended', 'plugin:react/recommended'],
  rules: {
    indent: ['error', 2],
    quotes: ['error', 'single'],
    'newline-after-var': ['error', 'always'],
    'import/newline-after-import': ['error', { count: 1 }],
    'comma-dangle': ['error', 'always-multiline'],
    'sort-keys': 'error',
    'lines-between-class-members': ['error', 'always'],
    'padding-line-between-statements': 'error',
    'newline-before-return': 'error',
  },
};
